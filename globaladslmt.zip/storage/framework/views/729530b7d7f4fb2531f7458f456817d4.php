<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h3>Add New Stepguide</h3>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('stepguide.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="title" class="form-label">Title</label>
            <input type="text" class="form-control" name="title" id="title" value="<?php echo e(old('title')); ?>" required>
        </div>
        <div class="mb-3">
            <label for="description" class="form-label">Description</label>
            <textarea class="form-control" name="description" id="description" required><?php echo e(old('description')); ?></textarea>
        </div>
        <div class="mb-3">
            <label for="icon" class="form-label">Icon (Font Awesome Class)</label>
            <input type="text" class="form-control" name="icon" id="icon" value="<?php echo e(old('icon')); ?>">
            <small>Example: fa-solid fa-box</small>
        </div>
        <div class="mb-3">
            <label for="serial_number" class="form-label">Serial Number</label>
            <input type="number" class="form-control" name="serial_number" id="serial_number" value="<?php echo e(old('serial_number')); ?>" required>
        </div>
        <button type="submit" class="btn btn-success"><i class="fa-solid fa-plus"></i> Create Stepguide</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\globaladslmt\resources\views\admin\stepguide\create.blade.php ENDPATH**/ ?>