<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h3>All Agents</h3>

    <!-- Search Input -->
    <div class="mb-3">
        <input type="text" id="agentSearch" class="form-control" placeholder="Search agents by name, email or country">
    </div>

    <?php if($agents->count() > 0): ?>
    <table class="table table-bordered mt-3" id="agentsTable">
        <thead>
            <tr>
                <th>#</th>
                <th>Name</th>
                <th>Email</th>
                <th>Country</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($agent->name); ?></td>
                <td><?php echo e($agent->email); ?></td>
                <td><?php echo e($agent->country); ?></td>
                <td>
                    <?php if($agent->status == 'pending'): ?>
                        <span class="badge bg-warning text-dark">Pending</span>
                    <?php elseif($agent->status == 'approved'): ?>
                        <span class="badge bg-success">Approved</span>
                    <?php else: ?>
                        <span class="badge bg-danger">Rejected</span>
                    <?php endif; ?>
                </td>
                <td>
                    <?php if($agent->status == 'pending'): ?>
                        <a href="<?php echo e(route('admin.agent.approve', $agent->id)); ?>" class="btn btn-success btn-sm">Approve</a>
                        <a href="<?php echo e(route('admin.agent.reject', $agent->id)); ?>" class="btn btn-danger btn-sm">Reject</a>
                    <?php endif; ?>
                    <a href="<?php echo e(route('agentcreate.edit', $agent->id)); ?>" class="btn btn-primary btn-sm">Edit</a>
                    <form action="<?php echo e(route('agentcreate.destroy', $agent->id)); ?>" method="POST" style="display:inline-block;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this agent?')">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php else: ?>
        <div class="alert alert-info mt-3">
            No agents in the database.
        </div>
    <?php endif; ?>
</div>

<!-- JS for Search -->
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const searchInput = document.getElementById('agentSearch');
        searchInput.addEventListener('keyup', function() {
            const filter = searchInput.value.toLowerCase();
            const rows = document.querySelectorAll('#agentsTable tbody tr');

            rows.forEach(row => {
                const cells = row.querySelectorAll('td');
                const match = Array.from(cells).some(cell =>
                    cell.textContent.toLowerCase().includes(filter)
                );
                row.style.display = match ? '' : 'none';
            });
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\globaladslmt\resources\views\admin\agentlist\index.blade.php ENDPATH**/ ?>