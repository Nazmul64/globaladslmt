<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <h5 class="mt-4">Packages</h5>

    <div class="card mb-4">
        <div class="card-header d-flex justify-content-between align-items-center">
            <span><i class="fa-solid fa-box"></i> Packages List</span>
            <a href="<?php echo e(route('package.create')); ?>" class="btn btn-primary btn-sm">Add Package</a>
        </div>

        <div class="card-body">
            <!-- Search Input -->
            <div class="mb-3">
                <input type="text" id="searchInput" class="form-control" placeholder="Search Packages...">
            </div>

            <table class="table table-bordered table-striped" id="packagesTable">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Price</th>
                        <th>Daily Income</th>
                        <th>Daily Limit</th>
                        <th>Photo</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($package->id); ?></td>
                            <td><?php echo e($package->package_name); ?></td>
                            <td>$<?php echo e($package->price); ?></td>
                            <td>$<?php echo e($package->daily_income); ?></td>
                            <td><?php echo e($package->daily_limit); ?></td>
                            <td>
                                <?php if($package->photo): ?>
                                    <img src="<?php echo e(asset('uploads/package/'.$package->photo)); ?>" alt="Package Image" width="50">
                                <?php else: ?>
                                    N/A
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="<?php echo e(route('package.edit', $package->id)); ?>" class="btn btn-sm btn-warning">Edit</a>
                                <form action="<?php echo e(route('package.destroy', $package->id)); ?>" method="POST" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure?')">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="text-center">No Packages Found</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- JavaScript Search -->

<script>
    document.getElementById('searchInput').addEventListener('keyup', function() {
        let filter = this.value.toLowerCase();
        let rows = document.querySelectorAll('#packagesTable tbody tr');

        rows.forEach(row => {
            let text = row.textContent.toLowerCase();
            row.style.display = text.includes(filter) ? '' : 'none';
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\globaladslmt\resources\views\admin\package\index.blade.php ENDPATH**/ ?>