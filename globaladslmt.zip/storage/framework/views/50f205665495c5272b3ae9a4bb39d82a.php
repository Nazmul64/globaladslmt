<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4>Agent Commission Setup List</h4>
        <a href="<?php echo e(route('agentcommission.create')); ?>" class="btn btn-primary btn-sm">+ Add New</a>
    </div>

    <table class="table table-bordered table-striped">
        <thead class="table-dark">
            <tr>
                <th>#</th>
                <th>Deposit Commission (%)</th>
                <th>Withdraw Commission (%)</th>
                <th>Agent Share (%)</th>
                <th>Admin Share (%)</th>
                <th>Type</th>
                <th>Status</th>
                <th width="120">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $commissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($key+1); ?></td>
                    <td><?php echo e($item->deposit_agent_commission); ?></td>
                    <td><?php echo e($item->withdraw_total_commission); ?></td>
                    <td><?php echo e($item->agent_share_percent); ?></td>
                    <td><?php echo e($item->admin_share_percent); ?></td>
                    <td><?php echo e(ucfirst($item->commission_type)); ?></td>
                    <td>
                        <?php if($item->status == 1): ?>
                            <span class="badge bg-success">Active</span>
                        <?php else: ?>
                            <span class="badge bg-danger">Inactive</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="<?php echo e(route('agentcommission.edit', $item->id)); ?>" class="btn btn-sm btn-info">Edit</a>
                        <form action="<?php echo e(route('agentcommission.destroy', $item->id)); ?>" method="POST" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button onclick="return confirm('Are you sure?')" class="btn btn-sm btn-danger">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="8" class="text-center">No data found!</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\globaladslmt\resources\views\admin\agentdepositewidhawcommission\index.blade.php ENDPATH**/ ?>