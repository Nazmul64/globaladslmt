<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="friendrequest-container">
        <div class="friendrequest-header d-flex justify-content-between align-items-center mb-3">
            <h2>Friend Requests</h2>
            <a href="#" class="friendrequest-see-all">See all</a>
        </div>

        <div class="friendrequest-grid">
            <?php $__empty_1 = true; $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="friendrequest-card">
                   <?php if(isset($request->photo) && !empty($request->photo)): ?>
                        <img src="<?php echo e(asset('uploads/profile/' . $request->photo)); ?>"
                            alt="<?php echo e($request->name ?? 'User'); ?>"
                            class="friendrequest-image">
                    <?php else: ?>
                        <img src="<?php echo e(asset('uploads/logo.png')); ?>"
                            alt="Default Logo"
                            class="friendrequest-image">
                    <?php endif; ?>


                    <div class="friendrequest-info">
                        <div class="friendrequest-name"><?php echo e($request['name']); ?></div>
                        <div class="friendrequest-mutual-friends">
                            <?php echo e($request['mutual_friends'] ?? 'No mutual friends'); ?>

                        </div>
                        <div class="friendrequest-button-group">
                            <button class="friendrequest-btn friendrequest-btn-confirm"
                                    onclick="acceptRequest(<?php echo e($request['id']); ?>, this)">
                                Confirm
                            </button>
                            <button class="friendrequest-btn friendrequest-btn-delete"
                                    onclick="rejectRequest(<?php echo e($request['id']); ?>, this)">
                                Delete
                            </button>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-center text-muted">No friend requests found.</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
function acceptRequest(senderId, btn) {
    $.ajax({
        url: "<?php echo e(route('user.friend.request.accept')); ?>",
        type: 'POST',
        data: {
            sender_id: senderId,
            _token: "<?php echo e(csrf_token()); ?>"
        },
        success: function(response) {
            alert(response.message);
            $(btn).closest('.friendrequest-card').fadeOut();
        },
        error: function(xhr) {
            alert(xhr.responseJSON?.message || 'Something went wrong.');
        }
    });
}

function rejectRequest(senderId, btn) {
    $.ajax({
        url: "<?php echo e(route('user.friend.request.reject')); ?>",
        type: 'POST',
        data: {
            sender_id: senderId,
            _token: "<?php echo e(csrf_token()); ?>"
        },
        success: function(response) {
            alert(response.message);
            $(btn).closest('.friendrequest-card').fadeOut();
        },
        error: function(xhr) {
            alert(xhr.responseJSON?.message || 'Something went wrong.');
        }
    });
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\globaladslmt\resources\views\frontend\frontendpages\friend_request_accept.blade.php ENDPATH**/ ?>