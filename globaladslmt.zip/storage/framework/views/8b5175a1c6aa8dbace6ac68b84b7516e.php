<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4>❌ Rejected Deposits</h4>
        <a href="<?php echo e(route('admin.agent.deposite.pending')); ?>" class="btn btn-sm btn-outline-primary">
            <i class="bi bi-clock"></i> Pending List
        </a>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <?php if($agent_deposite->isEmpty()): ?>
        <div class="alert alert-info text-center">
            No rejected deposits found.
        </div>
    <?php else: ?>
        <div class="card">
            <div class="card-body p-0">
                <table class="table table-striped table-bordered mb-0">
                    <thead class="table-danger">
                        <tr>
                            <th>#</th>
                            <th>Amount</th>
                            <th>Sender Account</th>
                            <th>Transaction ID</th>
                            <th>Screenshot</th>
                            <th>Status</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $agent_deposite; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $deposit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($key + 1); ?></td>
                                <td><?php echo e(number_format($deposit->amount, 2)); ?> ৳</td>
                                <td><?php echo e($deposit->sender_account); ?></td>
                                <td><?php echo e($deposit->transaction_id); ?></td>
                                <td>
                                    <?php if($deposit->photo): ?>
                                        <a href="<?php echo e(asset('uploads/agentdeposite/'.$deposit->photo)); ?>" target="_blank">
                                            <img src="<?php echo e(asset('uploads/agentdeposite/'.$deposit->photo)); ?>"
                                                 alt="Deposit Photo" width="50" height="50" style="object-fit: cover;">
                                        </a>
                                    <?php else: ?>
                                        <span class="text-muted">No Image</span>
                                    <?php endif; ?>
                                </td>
                                <td><span class="badge bg-danger">Rejected</span></td>
                                <td><?php echo e($deposit->created_at->format('d M Y, h:i A')); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\globaladslmt\resources\views\admin\agentdeposite\rejected.blade.php ENDPATH**/ ?>