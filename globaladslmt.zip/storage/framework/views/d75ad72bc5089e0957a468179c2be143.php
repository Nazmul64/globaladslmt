<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h2>Why Choose Us</h2>

    <div class="d-flex justify-content-between mb-3">
        <a href="<?php echo e(route('whychooseu.create')); ?>" class="btn btn-primary">Add New</a>
        <input type="text" id="searchInput" class="form-control w-25" placeholder="Search by title or description">
    </div>

    <table class="table table-bordered table-striped" id="whyChooseUsTable">
        <thead>
            <tr>
                <th>#</th>
                <th>Title</th>
                <th>Icon</th>
                <th>Description</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td class="title"><?php echo e($item->title); ?></td>
                    <td><i class="<?php echo e($item->icon); ?>"></i></td>
                    <td class="description"><?php echo e($item->description); ?></td>
                    <td>
                        <a href="<?php echo e(route('whychooseu.edit', $item->id)); ?>" class="btn btn-sm btn-warning">Edit</a>
                        <form action="<?php echo e(route('whychooseu.destroy', $item->id)); ?>" method="POST" style="display:inline-block;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm btn-danger" onclick="return confirm('Are you sure?')">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5" class="text-center text-muted">No items found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const searchInput = document.getElementById('searchInput');
        const table = document.getElementById('whyChooseUsTable');
        const rows = table.getElementsByTagName('tbody')[0].getElementsByTagName('tr');

        searchInput.addEventListener('keyup', function() {
            const filter = searchInput.value.toLowerCase();

            for (let i = 0; i < rows.length; i++) {
                const title = rows[i].querySelector('.title').textContent.toLowerCase();
                const description = rows[i].querySelector('.description').textContent.toLowerCase();

                if (title.includes(filter) || description.includes(filter)) {
                    rows[i].style.display = '';
                } else {
                    rows[i].style.display = 'none';
                }
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\globaladslmt\resources\views\admin\whychooseus\index.blade.php ENDPATH**/ ?>