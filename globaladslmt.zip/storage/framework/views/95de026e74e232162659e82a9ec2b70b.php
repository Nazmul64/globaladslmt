<?php $__env->startSection('content'); ?>

<main class="dashboard-main">
  <div class="dashboard-main-body">
    <div class="d-flex align-items-center justify-content-between mb-4">
      <h6 class="fw-semibold mb-0">Deposit Limits</h6>
      <a href="<?php echo e(route('depositelimit.create')); ?>" class="btn btn-primary btn-sm">Add New Limit</a>
    </div>
    <div class="card p-3">
      <table class="table table-bordered table-striped">
        <thead>
          <tr>
            <th>#</th>
            <th>Min Deposit</th>
            <th>Max Deposit</th>
            <th>Created At</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $limits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $limit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($loop->iteration); ?></td>
            <td><?php echo e(round($limit->min_deposit)); ?></td>
            <td><?php echo e(round($limit->max_deposit)); ?></td>
            <td><?php echo e($limit->created_at->format('d M, Y')); ?></td>
            <td>
              <a href="<?php echo e(route('depositelimit.edit', $limit->id)); ?>" class="btn btn-sm btn-warning">Edit</a>

              <form action="<?php echo e(route('depositelimit.destroy', $limit->id)); ?>" method="POST" style="display:inline-block;" onsubmit="return confirm('Are you sure?');">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button class="btn btn-sm btn-danger">Delete</button>
              </form>

            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
</main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\globaladslmt\resources\views\admin\depositelimit\index.blade.php ENDPATH**/ ?>