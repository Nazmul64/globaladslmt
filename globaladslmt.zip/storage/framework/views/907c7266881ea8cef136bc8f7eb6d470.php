<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <h5 class="mt-4">Edit Package</h5>

    <div class="card mb-4">
        <div class="card-body">
             <a class="btn btn-success mb-3" href="<?php echo e(route('package.index')); ?>">Back to Packages</a>
            <form action="<?php echo e(route('package.update', $package->id)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="mb-3">
                    <label class="form-label">Package Name</label>
                    <input type="text" name="package_name" class="form-control" value="<?php echo e(old('package_name', $package->package_name)); ?>" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Price ($)</label>
                    <input type="number" step="0.01" name="price" class="form-control" value="<?php echo e(old('price', $package->price)); ?>" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Daily Income ($)</label>
                    <input type="number" step="0.01" name="daily_income" class="form-control" value="<?php echo e(old('daily_income', $package->daily_income)); ?>" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Daily Limit</label>
                    <input type="number" name="daily_limit" class="form-control" value="<?php echo e(old('daily_limit', $package->daily_limit)); ?>" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Package Photo</label>
                    <input type="file" name="photo" class="form-control">
                    <?php if($package->photo): ?>
                        <img src="<?php echo e(asset('uploads/package/'.$package->photo)); ?>" alt="Package Image" width="100" class="mt-2">
                    <?php endif; ?>
                </div>

                <button type="submit" class="btn btn-success">Update Package</button>
                <a href="<?php echo e(route('package.index')); ?>" class="btn btn-secondary">Cancel</a>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\globaladslmt\resources\views\admin\package\edit.blade.php ENDPATH**/ ?>