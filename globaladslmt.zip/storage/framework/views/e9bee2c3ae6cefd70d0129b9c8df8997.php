<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h3>Referral Commission Setups</h3>

    <a href="<?php echo e(route('reffercommission.create')); ?>" class="btn btn-primary mb-3">Add New Level</a>

    <!-- Search Input -->
    <div class="mb-3">
        <input type="text" id="searchInput" class="form-control" placeholder="Search by level or percentage">
    </div>

    <?php if($setups->count() > 0): ?>
    <table class="table table-bordered" id="setupTable">
        <thead>
            <tr>
                <th>#</th>
                <th>Level</th>
                <th>Commission (%)</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $setups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($setup->reffer_level); ?></td>
                <td><?php echo e($setup->commission_percentage); ?></td>
                <td>
                    <a href="<?php echo e(route('reffercommission.edit', $setup->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                    <form action="<?php echo e(route('reffercommission.destroy', $setup->id)); ?>" method="POST" style="display:inline-block;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?')">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php else: ?>
        <div class="alert alert-info">No referral commission setups found.</div>
    <?php endif; ?>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('searchInput');
    searchInput.addEventListener('keyup', function() {
        const filter = searchInput.value.toLowerCase();
        const rows = document.querySelectorAll('#setupTable tbody tr');

        rows.forEach(row => {
            const cells = row.querySelectorAll('td');
            const match = Array.from(cells).some(cell =>
                cell.textContent.toLowerCase().includes(filter)
            );
            row.style.display = match ? '' : 'none';
        });
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\globaladslmt\resources\views\admin\reffercommission\index.blade.php ENDPATH**/ ?>