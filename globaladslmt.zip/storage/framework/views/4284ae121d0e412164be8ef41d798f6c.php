<?php $__env->startSection('content'); ?>
<div class="container mt-4" style="max-width: 650px;">
    <h4 class="mb-3 fw-bold">Edit Buy/Sell Post</h4>
    <form action="<?php echo e(route('agentbuysellpost.update', $agentBuySellPost->id)); ?>" method="POST" enctype="multipart/form-data" class="card p-4 shadow-sm">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="mb-3">
            <label for="category_id" class="form-label">Category</label>
            <select name="category_id" id="category_id" class="form-select" required>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->id); ?>" <?php echo e($agentBuySellPost->category_id == $category->id ? 'selected' : ''); ?>>
                        <?php echo e($category->category_name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="photo" class="form-label">Photo</label><br>
            <?php if($agentBuySellPost->photo): ?>
                <img src="<?php echo e(asset($agentBuySellPost->photo)); ?>" width="100" class="mb-2 rounded border">
            <?php endif; ?>
            <input type="file" class="form-control" name="photo" id="photo">
            <small class="text-muted">Leave empty if you don't want to change the photo.</small>
        </div>

        <div class="mb-3">
            <label for="trade_limit" class="form-label">Trade Limit (Min)</label>
            <input type="number" class="form-control" name="trade_limit" value="<?php echo e(old('trade_limit', $agentBuySellPost->trade_limit)); ?>" required>
        </div>

        <div class="mb-3">
            <label for="trade_limit_two" class="form-label">Trade Limit (Max)</label>
            <input type="number" class="form-control" name="trade_limit_two" value="<?php echo e(old('trade_limit_two', $agentBuySellPost->trade_limit_two)); ?>" required>
        </div>

        <div class="mb-3">
            <label for="available_balance" class="form-label">Available Balance</label>
            <input type="number" step="0.01" class="form-control" name="available_balance" value="<?php echo e(old('available_balance', $agentBuySellPost->available_balance)); ?>" required>
        </div>

        <div class="mb-3">
            <label for="duration" class="form-label">Duration (minutes)</label>
            <input type="number" class="form-control" name="duration" value="<?php echo e(old('duration', $agentBuySellPost->duration)); ?>" required>
        </div>

        <div class="mb-3">
            <label for="payment_name" class="form-label">Payment Name</label>
            <input type="text" class="form-control" name="payment_name" value="<?php echo e(old('payment_name', $agentBuySellPost->payment_name)); ?>" required>
        </div>

        <div class="mb-3">
            <label for="status" class="form-label fw-semibold">Status</label>
            <select class="form-select" name="status" id="status" required>
                <option value="approved" <?php echo e($agentBuySellPost->status === 'approved' ? 'selected' : ''); ?>>Approved</option>
                <option value="pending" <?php echo e($agentBuySellPost->status === 'pending' ? 'selected' : ''); ?>>Pending</option>
                <option value="rejected" <?php echo e($agentBuySellPost->status === 'rejected' ? 'selected' : ''); ?>>Rejected</option>
            </select>
        </div>

        <div class="d-flex justify-content-end gap-2 mt-3">
            <a href="<?php echo e(route('agentbuysellpost.index')); ?>" class="btn btn-secondary">
                <i class="bi bi-arrow-left"></i> Cancel
            </a>
            <button type="submit" class="btn btn-success">
                <i class="bi bi-save"></i> Update Post
            </button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('agent.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\globaladslmt\resources\views\agent\agentbuysellpost\edit.blade.php ENDPATH**/ ?>