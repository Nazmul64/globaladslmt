<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4>App Settings List</h4>
        <a href="<?php echo e(route('appsetting.create')); ?>" class="btn btn-success">
            <i class="bi bi-arrow-left-circle"></i> Back to Create
        </a>
    </div>
    <table class="table table-bordered table-striped">
        <thead class="table-dark">
            <tr>
                <th>ID</th>
                <th>App Theme</th>
                <th>Home Icon</th>
                <th>Currency</th>
                <th>Status</th>
                <th>Version</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $appsettings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($setting->id); ?></td>
                    <td><?php echo e($setting->app_theme); ?></td>
                    <td><?php echo e($setting->home_icon_themes); ?></td>
                    <td><?php echo e($setting->currency_symbol); ?></td>
                    <td><?php echo e($setting->enabled); ?></td>
                    <td><?php echo e($setting->app_version); ?></td>
                    <td>
                        <a href="<?php echo e(route('appsetting.edit', $setting->id)); ?>" class="btn btn-sm btn-primary" title="Edit">
                            <i class="bi bi-pencil-square"></i>
                        </a>

                        <form action="<?php echo e(route('appsetting.destroy', $setting->id)); ?>" method="POST" style="display:inline-block;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure to delete this setting?')" title="Delete">
                                <i class="bi bi-trash"></i>
                            </button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7" class="text-center">No App Settings found!</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\globaladslmt\resources\views\admin\appsetting\index.blade.php ENDPATH**/ ?>