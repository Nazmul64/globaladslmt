<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h3 class="mb-4">Rejected Deposits</h3>

    <!-- Search Input -->
    <div class="mb-3">
        <input type="text" id="rejectedDepositSearch" class="form-control" placeholder="Search by transaction ID, sender or amount">
    </div>

    <?php if($deposite_list->count() > 0): ?>
    <table class="table table-bordered mt-3" id="rejectedDepositsTable">
        <thead class="table-light">
            <tr>
                <th>#</th>
                <th>Amount</th>
                <th>Transaction ID</th>
                <th>Sender Account</th>
                <th>Photo</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $deposite_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deposit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($deposit->amount); ?></td>
                <td><?php echo e($deposit->transaction_id); ?></td>
                <td><?php echo e($deposit->sender_account); ?></td>
                <td>
                    <?php if($deposit->photo): ?>
                        <img src="<?php echo e(asset('uploads/deposits/' . $deposit->photo)); ?>"
                             alt="Deposit Photo" width="50" height="50" style="object-fit: cover;">
                    <?php else: ?>
                        <span class="text-muted">No Image</span>
                    <?php endif; ?>
                </td>
                <td>
                    <span class="badge bg-danger">Rejected</span>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php else: ?>
        <div class="alert alert-info mt-3">
            No rejected deposits found.
        </div>
    <?php endif; ?>
</div>

<!-- JS for Search -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('rejectedDepositSearch');
    searchInput.addEventListener('keyup', function() {
        const filter = searchInput.value.toLowerCase();
        const rows = document.querySelectorAll('#rejectedDepositsTable tbody tr');

        rows.forEach(row => {
            const cells = row.querySelectorAll('td');
            const match = Array.from(cells).some(cell =>
                cell.textContent.toLowerCase().includes(filter)
            );
            row.style.display = match ? '' : 'none';
        });
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\globaladslmt\resources\views\admin\depositeaproved\reject_list.blade.php ENDPATH**/ ?>