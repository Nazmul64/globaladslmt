<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h4>Rejected Deposits</h4>

    <?php if($rejected->count() > 0): ?>
    <table class="table table-bordered mt-3">
        <thead>
            <tr>
                <th>ID</th>
                <th>Amount</th>
                <th>Payment Method</th>
                <th>Transaction ID</th>
                <th>Screenshot</th>
                <th>Status</th>
                <th>Date</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $rejected; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deposit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($deposit->id); ?></td>
                <td><?php echo e(number_format($deposit->amount, 2)); ?>৳</td>
                <td><?php echo e($deposit->payment_method->method_number ?? '-'); ?></td>
                <td><?php echo e($deposit->transaction_id); ?></td>
                <td>
                    <?php if($deposit->photo): ?>
                        <img src="<?php echo e(asset('uploads/agentdeposite/'.$deposit->photo)); ?>" alt="Deposit Photo" style="max-width:100px;">
                    <?php else: ?>
                        N/A
                    <?php endif; ?>
                </td>
                <td><?php echo e(ucfirst($deposit->status)); ?></td>
                <td><?php echo e($deposit->created_at->format('d-m-Y H:i')); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php else: ?>
        <p>No rejected deposits found.</p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('agent.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\globaladslmt\resources\views\agent\deposite\rejected.blade.php ENDPATH**/ ?>