<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4>KYC Verification List</h4>
        <!-- 🔍 Search Bar -->
        <input type="text" id="kycSearch" class="form-control w-25" placeholder="Search KYC...">
    </div>

    <div class="table-responsive">
        <table id="kycTable" class="table table-bordered table-hover text-center align-middle">
            <thead class="table-dark">
                <tr>
                    <th>#</th>
                    <th>Document Type</th>
                    <th>First Photo</th>
                    <th>Second Photo</th>
                    <th>Status</th>
                    <th>Submitted At</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $kycs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $kyc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($index + 1); ?></td>
                    <td><?php echo e(ucfirst($kyc->document_type)); ?></td>
                    <td><img src="<?php echo e(asset('uploads/kyc/'.$kyc->document_first_part_photo)); ?>" width="60" height="60" class="rounded-circle border"></td>
                    <td><img src="<?php echo e(asset('uploads/kyc/'.$kyc->document_secound_part_photo)); ?>" width="60" height="60" class="rounded-circle border"></td>
                    <td>
                        <?php if($kyc->status == 'pending'): ?>
                            <span class="badge bg-warning text-dark">Pending</span>
                        <?php elseif($kyc->status == 'approved'): ?>
                            <span class="badge bg-success">Approved</span>
                        <?php else: ?>
                            <span class="badge bg-danger">Rejected</span>
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($kyc->created_at->format('d M, Y')); ?></td>
                    <td>
                        <?php if($kyc->status == 'pending'): ?>
                            <form action="<?php echo e(route('admin.kyc.approve', $kyc->id)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-success btn-sm">Approve</button>
                            </form>
                            <form action="<?php echo e(route('admin.kyc.reject', $kyc->id)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-danger btn-sm">Reject</button>
                            </form>
                        <?php elseif($kyc->status == 'approved'): ?>
                            <span class="text-success fw-bold">✔ Verified</span>
                        <?php else: ?>
                            <span class="text-danger fw-bold">✘ Rejected</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="8">No KYC records found.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- 🔍 JavaScript Live Search -->
<script>
document.getElementById('kycSearch').addEventListener('keyup', function() {
    let filter = this.value.toLowerCase();
    let rows = document.querySelectorAll('#kycTable tbody tr');

    rows.forEach(row => {
        let text = row.innerText.toLowerCase();
        row.style.display = text.includes(filter) ? '' : 'none';
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\globaladslmt\resources\views\admin\key\approved_list.blade.php ENDPATH**/ ?>