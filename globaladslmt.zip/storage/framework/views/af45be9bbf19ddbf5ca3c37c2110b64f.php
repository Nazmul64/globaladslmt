<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="refer-section">

        <!-- Header -->
        <div class="refer-header text-center mb-4">
            <h2><i class="fas fa-share-alt"></i> Refer & Earn</h2>
            <div class="refer-stats d-flex justify-content-center gap-4 flex-wrap">
                <div class="stat-item text-center">
                    <h4><?php echo e($referrals->count()); ?></h4>
                    <small>Total Referrals</small>
                </div>
                <div class="stat-item text-center">
                    <h4><?php echo e($referrals->filter(fn($r) => $r->packagebuys->count() > 0)->count()); ?></h4>
                    <small>Active Users</small>
                </div>
                <div class="stat-item text-center">
                    <h4>$<?php echo e(number_format($total_refer_income, 2)); ?></h4>
                    <small>Total Earnings</small>
                </div>
            </div>
        </div>

        <!-- Referral Table -->
        <div class="refer-list-section">
            <h3><i class="fas fa-users"></i> Your Referrals</h3>

            <!-- Bootstrap responsive table -->
            <div class="table-responsive">
                <table class="table table-bordered table-striped align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th style="width: 50px;">#</th>
                            <th>User</th>
                            <th>Status</th>
                            <th>Joined</th>
                            <th>Earning</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $referrals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $ref): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($index + 1); ?></td>
                            <td>
                                <div class="d-flex align-items-center">
                                    <div class="bg-primary text-white rounded-circle text-center me-2"
                                         style="width:40px;height:40px;line-height:40px;">
                                        <?php echo e(strtoupper(substr($ref->name, 0, 2))); ?>

                                    </div>
                                    <div>
                                        <strong><?php echo e($ref->name); ?></strong><br>
                                        <small class="text-muted"><?php echo e($ref->email); ?></small>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <?php if($ref->packagebuys->count() > 0): ?>
                                    <span class="badge bg-success">Active</span>
                                <?php else: ?>
                                    <span class="badge bg-warning text-dark">Pending</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($ref->created_at->format('M d, Y')); ?></td>
                            <td>$<?php echo e(number_format($ref->packagebuys->sum('amount') * 0.10, 2)); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="text-center text-muted">No referrals found.</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\globaladslmt\resources\views\frontend\frontendpages\reffer_list.blade.php ENDPATH**/ ?>