<div class="profile-container">
    <div class="profile-content">
        <!-- Profile Info Left -->
        <?php
             $usercopy = auth()->user();
         ?>
        <?php
            use App\Models\Kyc;
            $user = auth()->user();
            $kyc = Kyc::where('user_id', $user->id)->first();
        ?>
        <div class="profile-info">
          <div class="profile-role">
            <?php echo e($usercopy->name ?? ''); ?>

            <?php if(App\Models\Kyc::where('user_id', auth()->id())->where('status','approved')->exists()): ?> <span class="badge bg-success ms-2">
                <i class="fas fa-check-circle me-1"></i>
                Verified</span>
                <?php else: ?>
                 <span class="badge bg-danger ms-2"><i class="fas fa-times-circle me-1">
                    </i> Unverified</span>
                     <?php endif; ?>
                    </div>

                <?php if($usercopy): ?>
                <div class="info-row">
                    <div class="info-value refer-code" onclick="copyReferCode()" title="Click to copy" style="cursor:pointer; padding:5px;  display:inline-block;">
                        <span id="referCodeText" style="color:white;"><?php echo e($usercopy->ref_code); ?></span>
                        <i class="fas fa-copy copy-icon" style="color:white;"></i>
                    </div>
                </div>
                <?php endif; ?>

            <div class="tap-to-view" onclick="toggleBalance()">
                Tap to view balance
                <i class="fas fa-chevron-down tap-arrow" id="tapArrow"style="color:white;"></i>
            </div>
            <?php
                $user = auth()->user();
                $user_balance = App\Models\Deposite::where('user_id', $user->id)
                                    ->where('status', 'approved')
                                    ->sum('amount');
            ?>

            <!-- User Balance -->
            <div class="profile-details" id="balanceDetails">
                <div class="info-row">
                    <span class="info-label">Balance</span>
                    <div class="info-value">
                        <i class="fas fa-wallet coin-icon"></i>
                        <span id="balanceAmount" style="color:white;">
                            <?php echo e(round($user_balance ?? 0)); ?> BDT
                        </span>
                    </div>
                </div>
            </div>



        </div>

        <!-- Profile Avatar Right -->
        <div class="profile-avatar">
            <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=Felix" alt="Profile">
        </div>
    </div>
</div>

<!-- Toast -->
<div class="toast" id="toast">
    <i class="fas fa-check-circle"></i>
    <span>Refer code copied!</span>
</div>
<?php /**PATH E:\globaladslmt\resources\views\frontend\pages\profile.blade.php ENDPATH**/ ?>