<?php $__env->startSection('content'); ?>

 <div class="row">

        <div class="menu-card">
            <div class="menu-icon-circle">
                <a href="<?php echo e(route('frontend.ads')); ?>"><i class="fas fa-bookmark"style="color:white;"></i></a>
            </div>
            <div class="menu-label">Start Task</div>
        </div>

        <div class="menu-card">
            <div class="menu-icon-circle">
                <a href="<?php echo e(route('frontend.profile')); ?>"><i class="fas fa-user"style="color:white;"></i></a>
            </div>
            <div class="menu-label">Profile</div>
        </div>

        <div class="menu-card">
            <div class="menu-icon-circle">
                <a href="<?php echo e(route('frontend.refer.list')); ?>"><i class="fas fa-shopping-basket"style="color:white;"></i></a>
            </div>
            <div class="menu-label">Refer</div>
        </div>

        <div class="menu-card">
            <div class="menu-icon-circle">
                <a href="<?php echo e(route('frontend.options')); ?>"><i class="fas fa-user-plus"style="color:white;"></i></a>
            </div>
            <div class="menu-label">Options</div>
        </div>

        <div class="menu-card">
            <div class="menu-icon-circle">
                <a href="widthra.html"><i class="fas fa-money-bill-wave"style="color:white;"></i></a>
            </div>
            <div class="menu-label">Withdraw</div>
        </div>
        <div class="menu-card">
            <div class="menu-icon-circle">
                <a href="<?php echo e(route('frontend.payment.history')); ?>"><i class="fas fa-bell"style="color:white;"></i></a>
            </div>
            <div class="menu-label">Payment History</div>
        </div>

        <div class="menu-card">
            <div class="menu-icon-circle">
                <a href="agentlist.html"><i class="fas fa-user-check"style="color:white;"></i></a>
            </div>
            <div class="menu-label">Agent List</div>
        </div>

        <div class="menu-card">
            <div class="menu-icon-circle">
                <a href="<?php echo e(route('frontend.stepguide')); ?>"><i class="fas fa-box"style="color:white;"></i></a>
            </div>
            <div class="menu-label">How To Work</div>
        </div>

        <div class="menu-card">
            <div class="menu-icon-circle">
                <a href="<?php echo e(route('frontend.support')); ?>"><i class="fas fa-coins"style="color:white;"></i></a>
            </div>
            <div class="menu-label">Support</div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\globaladslmt\resources\views\frontend\index.blade.php ENDPATH**/ ?>