<?php $__env->startSection('content'); ?>
<div class="container my-4">
    <h4>Edit Support</h4>
    <a href="<?php echo e(route('support.index')); ?>" class="btn btn-secondary mb-3">Back to List</a>

    <form action="<?php echo e(route('support.update', $support->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="mb-3">
            <label for="name" class="form-label">Name</label>
            <input type="text" name="name" class="form-control" id="name" value="<?php echo e(old('name', $support->name)); ?>" required>
        </div>

        <div class="mb-3">
            <label for="url_link" class="form-label">URL Link</label>
            <input type="url" name="url_link" class="form-control" id="url_link" value="<?php echo e(old('url_link', $support->url_link)); ?>" required>
        </div>

        <div class="mb-3">
            <label for="icon" class="form-label">Icon (Font Awesome class)</label>
            <input type="text" name="icon" class="form-control" id="icon" value="<?php echo e(old('icon', $support->icon)); ?>" required>
        </div>

        <button type="submit" class="btn btn-success">Update Support</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\globaladslmt\resources\views\admin\support\edit.blade.php ENDPATH**/ ?>