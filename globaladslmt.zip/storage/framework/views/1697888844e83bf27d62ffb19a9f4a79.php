<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h3>Stepguide List</h3>
    <a href="<?php echo e(route('stepguide.create')); ?>" class="btn btn-primary mb-3">
        <i class="fa-solid fa-plus"></i> Add New Stepguide
    </a>
    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>#</th>
                <th>Title</th>
                <th>Description</th>
                <th>Icon</th>
                <th>Serial Number</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $stepguides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $step): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($key + 1); ?></td>
                <td><?php echo e($step->title); ?></td>
                <td><?php echo e($step->description); ?></td>
                <td><i class="<?php echo e($step->icon); ?>"></i> <?php echo e($step->icon); ?></td>
                <td><?php echo e($step->serial_number); ?></td>
                <td class="d-flex">
                    <a href="<?php echo e(route('stepguide.edit', $step->id)); ?>" class="btn btn-sm btn-warning x-2 me-2">
                        <i class="fa-solid fa-edit"></i>
                    </a>
                    <form action="<?php echo e(route('stepguide.destroy', $step->id)); ?>" method="POST" style="display:inline-block;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-sm btn-danger x-2 me-2" onclick="return confirm('Are you sure?')">
                            <i class="fa-solid fa-trash"></i>
                        </button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\globaladslmt\resources\views\admin\stepguide\index.blade.php ENDPATH**/ ?>