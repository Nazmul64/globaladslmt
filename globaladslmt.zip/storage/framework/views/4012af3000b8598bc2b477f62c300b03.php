<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h3>Approved Agents</h3>

    <!-- Search Input -->
    <div class="mb-3">
        <input type="text" id="agentSearch" class="form-control" placeholder="Search agents by name, email or country">
    </div>

    <?php if($agents->count() > 0): ?>
    <table class="table table-bordered mt-3" id="agentsTable">
        <thead>
            <tr>
                <th>#</th>
                <th>Name</th>
                <th>Email</th>
                <th>Country</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($agent->name); ?></td>
                <td><?php echo e($agent->email); ?></td>
                <td><?php echo e($agent->country); ?></td>
                <td><a class="btn btn-success"><?php echo e(ucfirst($agent->status)); ?></a></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php else: ?>
    <div class="alert alert-warning mt-3">
        No approved agents found in the database.
    </div>
    <?php endif; ?>
</div>

<!-- JS for Search -->
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const searchInput = document.getElementById('agentSearch');
        searchInput.addEventListener('keyup', function() {
            const filter = searchInput.value.toLowerCase();
            const rows = document.querySelectorAll('#agentsTable tbody tr');
            let visibleCount = 0;

            rows.forEach(row => {
                const cells = row.querySelectorAll('td');
                const match = Array.from(cells).some(cell =>
                    cell.textContent.toLowerCase().includes(filter)
                );
                row.style.display = match ? '' : 'none';
                if(match) visibleCount++;
            });

            const noDataMsg = document.getElementById('noDataMessage');
            if (!noDataMsg) {
                const msg = document.createElement('div');
                msg.id = 'noDataMessage';
                msg.className = 'alert alert-warning mt-3';
                msg.innerText = 'No agents match your search.';
                document.querySelector('.container').appendChild(msg);
            }
            document.getElementById('noDataMessage').style.display = visibleCount === 0 ? 'block' : 'none';
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\globaladslmt\resources\views\admin\agentlist\approved_list.blade.php ENDPATH**/ ?>