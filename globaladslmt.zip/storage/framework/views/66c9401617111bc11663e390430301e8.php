<?php $__env->startSection('head'); ?>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-content py-4 text-center">

    
    <?php if($ads && $ads->show_banner_ads === 'enabled'): ?>
    <div class="banner-ad mb-3" id="top-banner-wrapper">
        <div class="ad-badge">AD</div>
        <div class="ad-container" id="banner-top"></div>
    </div>
    <?php endif; ?>

    
    <div class="task-box card shadow-lg p-4 border-0 mb-4">
        <div class="task-icon mb-3">
            <i class="fas fa-tasks fa-3x text-primary"></i>
        </div>
        <div class="task-title h4 mb-2">Complete Your Task</div>
        <div class="task-description mb-3 text-muted">
            Click below to complete your daily task and earn rewards!
        </div>

        <?php if($packageBuy): ?>
        <div class="package-info mb-3">
            <div class="info-row">
                <span class="label">Package:</span>
                <span class="value"><?php echo e($packageBuy->package->package_name); ?></span>
            </div>
            <div class="info-row">
                <span class="label">Daily Income:</span>
                <span class="value">$<?php echo e(number_format($packageBuy->daily_income, 2)); ?></span>
            </div>
            <div class="info-row">
                <span class="label">Daily Limit:</span>
                <span class="value"><?php echo e($packageBuy->daily_limit); ?> Tasks</span>
            </div>
            <div class="info-row">
                <span class="label">Completed Today:</span>
                <span class="value" id="completed-today"><?php echo e($packageBuy->tasks_completed_today ?? 0); ?></span>
            </div>
        </div>
        <?php else: ?>
        <div class="alert alert-warning mb-3">
            <i class="fas fa-exclamation-triangle"></i> You have not purchased any package yet.
            <a href="<?php echo e(route('packages')); ?>" class="btn btn-sm btn-warning mt-2">Browse Packages</a>
        </div>
        <?php endif; ?>

        <div class="task-counter h5 mb-3">
            <span id="current-tasks"><?php echo e($packageBuy->tasks_completed_today ?? 0); ?></span>/<span id="max-tasks"><?php echo e($packageBuy ? $packageBuy->daily_limit : 0); ?></span>
        </div>

        <button class="btn btn-primary btn-lg pulse-button" id="taskButton"
                <?php if(!$packageBuy || ($packageBuy->tasks_completed_today ?? 0) >= $packageBuy->daily_limit): ?> disabled <?php endif; ?>>
            <i class="fas fa-hand-pointer"></i> Click to Complete Task
        </button>

        <div class="mt-3" id="ad-status">
            <i class="fas fa-circle-notch fa-spin"></i> <span id="status-text">Initializing...</span>
        </div>

        <div class="mt-2 small text-muted" id="earnings-today">
            Today's Earnings: $<span id="earnings-amount"><?php echo e(number_format(($packageBuy->tasks_completed_today ?? 0) * ($packageBuy->daily_income ?? 0), 2)); ?></span>
        </div>
    </div>

    
    <?php if($ads && $ads->show_native_ads === 'enabled'): ?>
    <div class="native-ad my-4" id="native-ad-wrapper">
        <div class="ad-badge">SPONSORED</div>
        <div class="ad-container" id="native-ad"></div>
    </div>
    <?php endif; ?>

    
    <?php if($ads && $ads->show_banner_ads === 'enabled'): ?>
    <div class="banner-ad mt-3" id="bottom-banner-wrapper">
        <div class="ad-badge">AD</div>
        <div class="ad-container" id="banner-bottom"></div>
    </div>
    <?php endif; ?>

</div>

<script>
// ==================== CONFIGURATION ====================
const APP_CONFIG = {
    maxTasks: <?php echo e($packageBuy ? $packageBuy->daily_limit : 0); ?>,
    dailyIncome: <?php echo e($packageBuy ? $packageBuy->daily_income : 0); ?>,
    tasksCompleted: <?php echo e($packageBuy->tasks_completed_today ?? 0); ?>,
    packageBuyId: <?php echo e($packageBuy->id ?? 'null'); ?>,
    userId: <?php echo e(Auth::id()); ?>,
    csrfToken: '<?php echo e(csrf_token()); ?>',
    taskCompleteUrl: '<?php echo e(route("task.complete")); ?>',
    ads: {
        appId: '<?php echo e($ads->app_id ?? ""); ?>',
        showBanner: <?php echo e($ads && $ads->show_banner_ads === 'enabled' ? 'true' : 'false'); ?>,
        showInterstitial: <?php echo e($ads && $ads->show_interstitial_ads === 'enabled' ? 'true' : 'false'); ?>,
        showNative: <?php echo e($ads && $ads->show_native_ads === 'enabled' ? 'true' : 'false'); ?>

    }
};

// ==================== STATE MANAGEMENT ====================
const AppState = {
    taskCount: APP_CONFIG.tasksCompleted,
    totalEarnings: APP_CONFIG.tasksCompleted * APP_CONFIG.dailyIncome,
    sdk: {
        loaded: false,
        ready: false,
        interstitialReady: false
    }
};

console.log('🎯 App Config:', APP_CONFIG);
console.log('📊 Initial State:', AppState);

// ==================== START.IO SDK LOADER ====================
class StartIOSDK {
    constructor() {
        this.initialized = false;
    }

    async load() {
        if (!APP_CONFIG.ads.appId) {
            console.warn('⚠️ No Start.io App ID configured');
            return false;
        }

        console.log('📦 Loading Start.io SDK...');
        this.updateStatus('Loading ads SDK...', 'info');

        try {
            // Inject config
            await this.injectConfig();

            // Load SDK script
            await this.loadScript();

            // Wait for SDK ready
            await this.waitForReady();

            console.log('✅ Start.io SDK fully loaded');
            AppState.sdk.loaded = true;
            AppState.sdk.ready = true;
            this.updateStatus('Ads ready', 'success');

            return true;
        } catch (error) {
            console.error('❌ SDK load failed:', error);
            this.updateStatus('Ads unavailable', 'warning');
            return false;
        }
    }

    injectConfig() {
        return new Promise((resolve) => {
            const script = document.createElement('script');
            script.type = 'text/javascript';
            script.textContent = `
                window.startAppConfig = {
                    appId: "${APP_CONFIG.ads.appId}",
                    userId: "${APP_CONFIG.userId}"
                };
            `;
            document.head.appendChild(script);
            console.log('✅ Config injected');
            resolve();
        });
    }

    loadScript() {
        return new Promise((resolve, reject) => {
            const script = document.createElement('script');
            script.src = 'https://s.start.io/js/sdk/v1/start.min.js';
            script.async = true;

            script.onload = () => {
                console.log('✅ SDK script loaded');
                resolve();
            };

            script.onerror = (error) => {
                console.error('❌ SDK script load failed:', error);
                reject(error);
            };

            document.head.appendChild(script);
        });
    }

    waitForReady() {
        return new Promise((resolve, reject) => {
            let attempts = 0;
            const maxAttempts = 60;

            const check = setInterval(() => {
                attempts++;

                if (typeof window.StartApp !== 'undefined') {
                    clearInterval(check);
                    console.log('✅ StartApp object available');
                    resolve(true);
                } else if (attempts >= maxAttempts) {
                    clearInterval(check);
                    console.error('❌ SDK timeout');
                    reject(new Error('SDK timeout'));
                }
            }, 500);
        });
    }

    updateStatus(message, type) {
        const icons = {
            info: 'circle-notch fa-spin',
            success: 'check-circle',
            warning: 'exclamation-triangle',
            error: 'times-circle'
        };

        const statusEl = document.getElementById('ad-status');
        if (statusEl) {
            statusEl.className = `mt-3 text-${type}`;
            statusEl.innerHTML = `<i class="fas fa-${icons[type]}"></i> <span>${message}</span>`;
        }
    }
}

// ==================== AD MANAGER ====================
class AdManager {
    constructor() {
        this.sdk = typeof window.StartApp !== 'undefined' ? window.StartApp : null;
    }

    isReady() {
        return AppState.sdk.ready && this.sdk !== null;
    }

    loadBanners() {
        if (!this.isReady() || !APP_CONFIG.ads.showBanner) return;

        console.log('🎯 Loading banners...');

        // Top banner
        if (document.getElementById('banner-top')) {
            this.sdk.showBanner({
                containerId: 'banner-top',
                size: '320x50',
                onLoad: () => console.log('✅ Top banner loaded'),
                onError: (err) => console.error('❌ Top banner error:', err)
            });
        }

        // Bottom banner
        if (document.getElementById('banner-bottom')) {
            this.sdk.showBanner({
                containerId: 'banner-bottom',
                size: '320x50',
                onLoad: () => console.log('✅ Bottom banner loaded'),
                onError: (err) => console.error('❌ Bottom banner error:', err)
            });
        }
    }

    loadNative() {
        if (!this.isReady() || !APP_CONFIG.ads.showNative) return;

        const container = document.getElementById('native-ad');
        if (!container) return;

        console.log('🎯 Loading native ad...');

        this.sdk.showNativeAd({
            containerId: 'native-ad',
            onLoad: () => console.log('✅ Native ad loaded'),
            onError: (err) => console.error('❌ Native ad error:', err)
        });
    }

    loadInterstitial() {
        if (!this.isReady() || !APP_CONFIG.ads.showInterstitial) return;
        if (!this.sdk.loadInterstitial) return;

        console.log('🎯 Loading interstitial...');

        this.sdk.loadInterstitial({
            onLoad: () => {
                AppState.sdk.interstitialReady = true;
                console.log('✅ Interstitial ready');
            },
            onError: (err) => {
                AppState.sdk.interstitialReady = false;
                console.error('❌ Interstitial error:', err);
            }
        });
    }

    showInterstitial() {
        return new Promise((resolve) => {
            if (!this.isReady() || !AppState.sdk.interstitialReady) {
                console.warn('⚠️ Interstitial not ready');
                resolve(false);
                return;
            }

            if (!this.sdk.showInterstitial) {
                resolve(false);
                return;
            }

            console.log('📺 Showing interstitial...');

            this.sdk.showInterstitial({
                onShow: () => console.log('✅ Interstitial showing'),
                onClose: () => {
                    console.log('✅ Interstitial closed');
                    setTimeout(() => this.loadInterstitial(), 1000);
                    resolve(true);
                },
                onError: (err) => {
                    console.error('❌ Show error:', err);
                    resolve(false);
                }
            });
        });
    }

    loadAll() {
        console.log('📢 Loading all ads...');
        this.loadBanners();
        this.loadNative();
        this.loadInterstitial();
    }
}

// ==================== UI MANAGER ====================
class UIManager {
    static updateTaskCount() {
        const elements = {
            current: document.getElementById('current-tasks'),
            completed: document.getElementById('completed-today'),
            earnings: document.getElementById('earnings-amount'),
            button: document.getElementById('taskButton')
        };

        if (elements.current) elements.current.textContent = AppState.taskCount;
        if (elements.completed) elements.completed.textContent = AppState.taskCount;
        if (elements.earnings) elements.earnings.textContent = AppState.totalEarnings.toFixed(2);

        if (AppState.taskCount >= APP_CONFIG.maxTasks && elements.button) {
            elements.button.disabled = true;
            elements.button.innerHTML = '<i class="fas fa-check-circle"></i> All Tasks Completed!';
            elements.button.classList.remove('pulse-button');
            elements.button.style.background = '#28a745';
        }
    }

    static showNotification(message, type = 'info') {
        console.log(`🔔 ${message}`);

        const notif = document.createElement('div');
        notif.className = `notification notification-${type}`;

        const icons = { success: 'check-circle', error: 'times-circle', warning: 'exclamation-circle', info: 'info-circle' };

        notif.innerHTML = `
            <div class="notification-content">
                <i class="fas fa-${icons[type]}"></i>
                <span>${message}</span>
            </div>
        `;

        document.body.appendChild(notif);
        setTimeout(() => notif.classList.add('show'), 100);

        setTimeout(() => {
            notif.classList.remove('show');
            setTimeout(() => notif.remove(), 300);
        }, 3000);
    }
}

// ==================== TASK HANDLER ====================
class TaskHandler {
    constructor(adManager) {
        this.adManager = adManager;
    }

    async complete() {
        console.log('🎯 Task completion initiated');

        if (AppState.taskCount >= APP_CONFIG.maxTasks) {
            UIManager.showNotification('Daily limit reached!', 'warning');
            return;
        }

        if (!APP_CONFIG.packageBuyId) {
            UIManager.showNotification('No package purchased!', 'error');
            return;
        }

        const button = document.getElementById('taskButton');
        button.disabled = true;
        button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';

        // Show ad if enabled
        if (APP_CONFIG.ads.showInterstitial && AppState.sdk.interstitialReady) {
            console.log('📺 Showing ad before task...');
            await this.adManager.showInterstitial();
            await new Promise(r => setTimeout(r, 500));
        }

        // Submit task
        try {
            const response = await fetch(APP_CONFIG.taskCompleteUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': APP_CONFIG.csrfToken
                },
                body: JSON.stringify({ package_buy_id: APP_CONFIG.packageBuyId })
            });

            const data = await response.json();

            if (data.success) {
                AppState.taskCount++;
                AppState.totalEarnings = AppState.taskCount * APP_CONFIG.dailyIncome;
                UIManager.updateTaskCount();
                UIManager.showNotification(`Task completed! Earned $${APP_CONFIG.dailyIncome.toFixed(2)}`, 'success');
            } else {
                UIManager.showNotification(data.message || 'Task failed', 'error');
            }
        } catch (error) {
            console.error('❌ Task error:', error);
            UIManager.showNotification('Error completing task', 'error');
        }

        button.disabled = AppState.taskCount >= APP_CONFIG.maxTasks;
        button.innerHTML = '<i class="fas fa-hand-pointer"></i> Click to Complete Task';
    }
}

// ==================== APP INITIALIZATION ====================
class App {
    constructor() {
        this.sdkLoader = new StartIOSDK();
        this.adManager = null;
        this.taskHandler = null;
    }

    async init() {
        console.log('🚀 Initializing app...');
        console.log('📱 User Agent:', navigator.userAgent);

        // Update UI
        UIManager.updateTaskCount();

        // Load SDK
        const sdkLoaded = await this.sdkLoader.load();

        if (sdkLoaded) {
            this.adManager = new AdManager();
            this.taskHandler = new TaskHandler(this.adManager);

            // Load ads
            this.adManager.loadAll();

            // Setup task button
            this.setupTaskButton();
        }

        console.log('✅ App initialized');
    }

    setupTaskButton() {
        const button = document.getElementById('taskButton');
        if (button && !button.disabled) {
            button.addEventListener('click', () => {
                if (this.taskHandler) {
                    this.taskHandler.complete();
                }
            });
        }
    }
}

// ==================== START APP ====================
let appInstance = null;

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        appInstance = new App();
        appInstance.init();
    });
} else {
    appInstance = new App();
    appInstance.init();
}

// Backup: window load
window.addEventListener('load', () => {
    if (!AppState.sdk.loaded) {
        console.log('🔄 Retry on window load...');
        if (appInstance) appInstance.init();
    }
});

// ==================== DEBUG HELPERS ====================
window.debugApp = () => {
    console.log('🔍 Debug Info:');
    console.log('- Config:', APP_CONFIG);
    console.log('- State:', AppState);
    console.log('- StartApp exists:', typeof window.StartApp !== 'undefined');
    if (typeof window.StartApp !== 'undefined') {
        console.log('- StartApp methods:', Object.keys(window.StartApp));
    }
};

window.reloadAds = () => {
    console.log('🔄 Reloading ads...');
    if (appInstance && appInstance.adManager) {
        appInstance.adManager.loadAll();
    }
};
</script>

<style>
/* Container */
.container-content {
    max-width: 600px;
    margin: 0 auto;
}

/* Ad containers */
.banner-ad, .native-ad {
    position: relative;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    border-radius: 12px;
    padding: 15px;
    min-height: 70px;
    box-shadow: 0 4px 15px rgba(0,0,0,0.1);
    overflow: hidden;
}

.ad-badge {
    position: absolute;
    top: 8px;
    right: 8px;
    background: rgba(255,255,255,0.9);
    color: #333;
    font-size: 9px;
    font-weight: 700;
    padding: 4px 8px;
    border-radius: 10px;
    letter-spacing: 0.5px;
    z-index: 10;
}

.ad-container {
    background: white;
    border-radius: 8px;
    min-height: 50px;
    display: flex;
    align-items: center;
    justify-content: center;
    position: relative;
}

.ad-container:empty::after {
    content: 'Loading ad...';
    color: #999;
    font-size: 12px;
}

.native-ad .ad-container {
    min-height: 250px;
}

/* Task box */
.task-box {
    border-radius: 16px;
    background: white;
    position: relative;
    overflow: hidden;
}

.task-box::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
    background: linear-gradient(90deg, #667eea, #764ba2);
}

.task-icon i {
    animation: pulse 2s ease-in-out infinite;
}

@keyframes pulse {
    0%, 100% { transform: scale(1); }
    50% { transform: scale(1.1); }
}

/* Package info */
.package-info {
    background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
    padding: 20px;
    border-radius: 12px;
    border-left: 4px solid #667eea;
}

.info-row {
    display: flex;
    justify-content: space-between;
    margin-bottom: 10px;
    padding: 8px 0;
    border-bottom: 1px solid #e0e0e0;
}

.info-row:last-child {
    border-bottom: none;
    margin-bottom: 0;
}

.info-row .label {
    font-weight: 600;
    color: #555;
}

.info-row .value {
    font-weight: 700;
    color: #667eea;
}

/* Button */
.btn-primary {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    border: none;
    font-weight: 600;
    transition: all 0.3s ease;
    position: relative;
    overflow: hidden;
}

.btn-primary:hover:not(:disabled) {
    transform: translateY(-2px);
    box-shadow: 0 8px 20px rgba(102, 126, 234, 0.4);
}

.btn-primary:disabled {
    background: #6c757d;
    cursor: not-allowed;
}

.pulse-button {
    animation: buttonPulse 2s infinite;
}

@keyframes buttonPulse {
    0%, 100% { box-shadow: 0 0 0 0 rgba(102, 126, 234, 0.7); }
    50% { box-shadow: 0 0 0 15px rgba(102, 126, 234, 0); }
}

/* Task counter */
.task-counter {
    font-weight: 700;
    color: #667eea;
    font-size: 1.8rem;
}

/* Notification */
.notification {
    position: fixed;
    top: 20px;
    right: 20px;
    background: white;
    padding: 15px 20px;
    border-radius: 8px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    transform: translateX(400px);
    transition: transform 0.3s ease;
    z-index: 9999;
    max-width: 300px;
}

.notification.show {
    transform: translateX(0);
}

.notification-content {
    display: flex;
    align-items: center;
    gap: 10px;
}

.notification-success { border-left: 4px solid #28a745; }
.notification-error { border-left: 4px solid #dc3545; }
.notification-warning { border-left: 4px solid #ffc107; }

.notification-success i { color: #28a745; }
.notification-error i { color: #dc3545; }
.notification-warning i { color: #ffc107; }

/* Status colors */
.text-success { color: #28a745 !important; }
.text-danger { color: #dc3545 !important; }
.text-warning { color: #ffc107 !important; }
.text-info { color: #17a2b8 !important; }

/* Responsive */
@media (max-width: 768px) {
    .container-content {
        padding: 10px !important;
    }

    .notification {
        right: 10px;
        left: 10px;
        max-width: none;
    }
}

/* Webview optimizations */
body {
    -webkit-touch-callout: none;
    -webkit-user-select: none;
    -webkit-tap-highlight-color: transparent;
}

* {
    -webkit-overflow-scrolling: touch;
}
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\globaladslmt\resources\views/frontend/frontendpages/ads.blade.php ENDPATH**/ ?>