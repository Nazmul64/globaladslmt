<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="card shadow">
        <div class="card-header bg-primary text-white">
            <h5 class="mb-0">Create New Ad</h5>
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('ads.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <div class="mb-3">
                    <label for="code" class="form-label">Ad Code</label>
                    <textarea name="code" id="code" class="form-control" rows="5" required><?php echo e(old('code')); ?></textarea>
                    <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-3">
                    <label for="show_mrce_ads" class="form-label">Show MRCE Ads</label>
                    <select name="show_mrce_ads" id="show_mrce_ads" class="form-control" required>
                        <option value="">-- Select --</option>
                        <option value="enabled" <?php echo e(old('show_mrce_ads')=='enabled'?'selected':''); ?>>Enabled</option>
                        <option value="disabled" <?php echo e(old('show_mrce_ads')=='disabled'?'selected':''); ?>>Disabled</option>
                    </select>
                    <?php $__errorArgs = ['show_mrce_ads'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-3">
                    <label for="show_button_timer_ads" class="form-label">Show Button Timer Ads</label>
                    <select name="show_button_timer_ads" id="show_button_timer_ads" class="form-control" required>
                        <option value="">-- Select --</option>
                        <option value="enabled" <?php echo e(old('show_button_timer_ads')=='enabled'?'selected':''); ?>>Enabled</option>
                        <option value="disabled" <?php echo e(old('show_button_timer_ads')=='disabled'?'selected':''); ?>>Disabled</option>
                    </select>
                    <?php $__errorArgs = ['show_button_timer_ads'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-3">
                    <label for="show_banner_ads" class="form-label">Show Banner Ads</label>
                    <select name="show_banner_ads" id="show_banner_ads" class="form-control" required>
                        <option value="">-- Select --</option>
                        <option value="enabled" <?php echo e(old('show_banner_ads')=='enabled'?'selected':''); ?>>Enabled</option>
                        <option value="disabled" <?php echo e(old('show_banner_ads')=='disabled'?'selected':''); ?>>Disabled</option>
                    </select>
                    <?php $__errorArgs = ['show_banner_ads'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <button type="submit" class="btn btn-success w-100">Create Ad</button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\globaladslmt\resources\views\admin\ads\create.blade.php ENDPATH**/ ?>