<?php $__env->startSection('content'); ?>
<div class="container">

    <!-- Recent Payments -->
    <div class="section-title">
        <i class="fas fa-history"></i>
        Recent Transactions
    </div>

    <div class="payment-list">
        <?php $__empty_1 = true; $__currentLoopData = $deposits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deposit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="payment-card">
            <div class="payment-header">
                <div class="payment-method">
                    <div class="method-icon">
                        <?php if($deposit->method == 'PayPal'): ?>
                            <i class="fab fa-paypal"></i>
                        <?php elseif($deposit->method == 'Bkash'): ?>
                            <i class="fas fa-mobile-alt"></i>
                        <?php else: ?>
                            <i class="fas fa-university"></i>
                        <?php endif; ?>
                    </div>
                    <span><?php echo e($deposit->method); ?></span>
                </div>
                <div class="payment-amount">৳<?php echo e(round($deposit->amount)); ?></div>
            </div>
            <div class="payment-details">
                <div class="detail-row">
                    <span class="detail-label">Transaction ID:</span>
                    <span class="detail-value">#<?php echo e($deposit->transaction_id ?? ''); ?></span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Date:</span>
                    <span class="detail-value"><?php echo e($deposit->created_at->format('M d, Y')); ?></span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Status:</span>
                    <?php if($deposit->status == 'completed'): ?>
                        <span class="status-badge status-success">Completed</span>
                    <?php elseif($deposit->status == 'pending'): ?>
                        <span class="status-badge status-pending">Processing</span>
                    <?php else: ?>
                        <span class="status-badge status-secondary"><?php echo e(ucfirst($deposit->status)); ?></span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="text-center text-muted p-3">
            No transactions found.
        </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\globaladslmt\resources\views\frontend\frontendpages\payment_history.blade.php ENDPATH**/ ?>