<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="card shadow border-0">
        <div class="card-header bg-success text-white d-flex justify-content-between align-items-center">
            <h5 class="mb-0">Approved KYC List</h5>
        </div>

        <div class="card-body">
            <?php if(session('success')): ?>
                <div class="alert alert-success text-center"><?php echo e(session('success')); ?></div>
            <?php endif; ?>

            <?php if($approvedKycs->isEmpty()): ?>
                <div class="alert alert-info text-center">No approved KYC records found.</div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-bordered table-striped text-center align-middle">
                        <thead class="table-success">
                            <tr>
                                <th>#</th>
                                <th>Document Type</th>
                                <th>Front Photo</th>
                                <th>Back Photo</th>
                                <th>Status</th>
                                <th>Approved Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $approvedKycs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $kyc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($index + 1); ?></td>
                                    <td><?php echo e(ucfirst($kyc->document_type ?? 'N/A')); ?></td>

                                    <td>
                                        <?php if($kyc->document_first_part_photo): ?>
                                            <img src="<?php echo e(asset('uploads/agent_kyc/'.$kyc->document_first_part_photo)); ?>"
                                                 width="60" height="60" class="rounded border">
                                        <?php else: ?>
                                            <span class="text-muted">No Photo</span>
                                        <?php endif; ?>
                                    </td>

                                    <td>
                                        <?php if($kyc->document_secound_part_photo): ?>
                                            <img src="<?php echo e(asset('uploads/agent_kyc/'.$kyc->document_secound_part_photo)); ?>"
                                                 width="60" height="60" class="rounded border">
                                        <?php else: ?>
                                            <span class="text-muted">No Photo</span>
                                        <?php endif; ?>
                                    </td>

                                    <td>
                                        <span class="badge bg-success">Approved</span>
                                    </td>

                                    <td><?php echo e($kyc->updated_at ? $kyc->updated_at->format('d M, Y') : 'N/A'); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\globaladslmt\resources\views\admin\agentkycapproved\agent_kyc_approve_list.blade.php ENDPATH**/ ?>