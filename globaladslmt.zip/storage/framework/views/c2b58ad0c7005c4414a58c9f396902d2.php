<?php $__env->startSection('content'); ?>
 <div class="container">

        <!-- Steps Section -->
        <div class="steps-section">
            <h2 class="section-title">
                <i class="fas fa-list-ol"></i>
                Step by Step Guide
            </h2>
           <?php $__currentLoopData = $step_guides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="step-card">
                <div class="step-header">
                    <div class="step-number"><?php echo e($item->serial_number ?? ''); ?></div>
                    <div class="step-title"><?php echo e($item->title ?? ''); ?></div>
                </div>
                <p class="step-description">
                    <?php echo e($item->description ?? ''); ?>

                </p>
                <i class=" <?php echo e($item->icon ?? ''); ?>"></i>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <!-- Features Grid -->
        <h2 class="section-title">
            <i class="fas fa-star"></i>
            Why Choose Us
        </h2>
        <div class="features-grid-container">
             <?php $__currentLoopData = $why_choose_us_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="features-grid">
                    <div class="feature-card">
                        <div class="feature-icon">
                            <i class="<?php echo e($item->icon ?? ''); ?>"></i>
                        </div>
                        <div class="feature-title"><?php echo e($item->title ?? ''); ?></div>
                        <p class="feature-description">
                            <?php echo e($item->description ?? ''); ?>

                        </p>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\globaladslmt\resources\views\frontend\frontendpages\stepguide.blade.php ENDPATH**/ ?>