<?php $__env->startSection('content'); ?>
<div class="container mt-4" style="max-width: 600px;">
    <h4 class="mb-3 fw-bold">Edit Category</h4>

    <form action="<?php echo e(route('category.update', $category->id)); ?>" method="POST" class="card p-4 shadow-sm">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="mb-3">
            <label for="category_name" class="form-label fw-semibold">Category Name</label>
            <input type="text" class="form-control" name="category_name" id="category_name" value="<?php echo e(old('category_name', $category->category_name)); ?>" required>
            <?php $__errorArgs = ['category_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="d-flex justify-content-end gap-2 mt-3">
            <a href="<?php echo e(route('category.index')); ?>" class="btn btn-secondary">
                <i class="bi bi-arrow-left"></i> Cancel
            </a>
            <button type="submit" class="btn btn-success">
                <i class="bi bi-save"></i> Update Category
            </button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\globaladslmt\resources\views\admin\category\edit.blade.php ENDPATH**/ ?>