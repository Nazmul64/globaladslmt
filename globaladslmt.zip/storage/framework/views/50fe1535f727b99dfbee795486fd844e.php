<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h3>Package Buy List</h3>

    <!-- Search Input -->
    <div class="mb-3">
        <input type="text" id="searchInput" class="form-control" placeholder="Search by user, package or status...">
    </div>

    <table class="table table-bordered table-striped mt-3" id="packageBuyTable">
        <thead>
            <tr>
                <th>ID</th>
                <th>User</th>
                <th>Package</th>
                <th>Amount</th>
                <th>Status</th>
                <th>Purchase Date</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $packageBuys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($buy->id); ?></td>
                <td><?php echo e($buy->user->name ?? 'N/A'); ?></td>
                <td><?php echo e($buy->package->package_name ?? 'N/A'); ?></td>
                <td><?php echo e(round($buy->amount)); ?> BDT</td>
                <td><?php echo e(ucfirst($buy->status)); ?></td>
                <td><?php echo e($buy->created_at->format('d M Y, h:i A')); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<!-- JS for client-side search -->
<script>
document.getElementById('searchInput').addEventListener('keyup', function() {
    let filter = this.value.toLowerCase();
    let rows = document.querySelectorAll('#packageBuyTable tbody tr');

    rows.forEach(row => {
        let text = row.innerText.toLowerCase();
        row.style.display = text.includes(filter) ? '' : 'none';
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\globaladslmt\resources\views\admin\packagebuylist\index.blade.php ENDPATH**/ ?>