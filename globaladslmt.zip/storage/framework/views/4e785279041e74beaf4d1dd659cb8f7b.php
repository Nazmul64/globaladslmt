

<?php $__env->startSection('content'); ?>
<table class="table table-bordered">
    <thead>
        <tr>
            <th>User</th>
            <th>Amount</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $req): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($req->user->name); ?></td>
            <td><?php echo e($req->amount); ?></td>
            <td><span class="badge bg-warning"><?php echo e($req->status); ?></span></td>
            <td>
                <form action="<?php echo e(route('agent.deposit.accept', $req->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-success btn-sm">Accept</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('agent.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\globaladslmt\resources\views/agent/userdepositewidhrawaccept/index.blade.php ENDPATH**/ ?>