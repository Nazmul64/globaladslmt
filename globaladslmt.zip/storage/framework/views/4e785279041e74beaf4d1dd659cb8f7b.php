<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h4 class="mb-3 text-center">💵 User Deposit Requests</h4>

    <table class="table table-bordered table-hover align-middle text-center shadow-sm">
        <thead class="table-primary">
            <tr>
                <th>User Name</th>
                <th>Amount ($)</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $req): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($req->user->name ?? 'N/A'); ?></td>
                <td>$<?php echo e(number_format($req->amount, 2)); ?></td>
                <td>
                    <span class="badge
                        <?php if($req->status == 'pending'): ?> bg-warning
                        <?php elseif($req->status == 'agent_confirmed'): ?> bg-info
                        <?php elseif($req->status == 'user_submitted'): ?> bg-primary
                        <?php elseif($req->status == 'completed'): ?> bg-success
                        <?php else: ?> bg-danger <?php endif; ?>">
                        <?php echo e(ucfirst($req->status)); ?>

                    </span>
                </td>
                <td>
                    <?php if($req->status == 'pending'): ?>
                        <!-- Agent Accept -->
                        <form action="<?php echo e(route('agent.deposit.accept', $req->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-success btn-sm w-100">
                                ✅ Accept
                            </button>
                        </form>

                    <?php elseif($req->status == 'user_submitted'): ?>
                        <!-- View Payment Modal Trigger -->
                        <button type="button" class="btn btn-primary btn-sm w-100"
                            data-bs-toggle="modal" data-bs-target="#paymentModal<?php echo e($req->id); ?>">
                            👁 View Payment
                        </button>

                        <!-- Payment Modal -->
                        <div class="modal fade" id="paymentModal<?php echo e($req->id); ?>" tabindex="-1"
                             aria-labelledby="paymentModalLabel<?php echo e($req->id); ?>" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered">
                                <div class="modal-content">
                                    <div class="modal-header bg-light">
                                        <h5 class="modal-title">Payment Details - <?php echo e($req->user->name); ?></h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                    </div>

                                    <div class="modal-body text-start">
                                        <p><strong>Transaction ID:</strong> <?php echo e($req->transaction_id ?? 'N/A'); ?></p>
                                        <p><strong>Sender Account:</strong> <?php echo e($req->sender_account ?? 'N/A'); ?></p>
                                        <p><strong>Screenshot:</strong></p>
                                        <?php if($req->photo): ?>
                                            <img src="<?php echo e(asset('uploads/deposits/' . $req->photo)); ?>"
                                                 class="img-fluid rounded shadow-sm border">
                                        <?php else: ?>
                                            <p class="text-muted">No screenshot uploaded.</p>
                                        <?php endif; ?>
                                    </div>

                                    <div class="modal-footer">
                                        <form action="<?php echo e(route('agent.deposit.final', $req->id)); ?>" method="POST" class="w-100">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn btn-success w-100">
                                                ✅ Confirm Deposit
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php else: ?>
                        <span class="text-muted">No action available</span>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="4" class="text-muted">No deposit requests available.</td>
            </tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('agent.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\globaladslmt\resources\views/agent/userdepositewidhrawaccept/index.blade.php ENDPATH**/ ?>