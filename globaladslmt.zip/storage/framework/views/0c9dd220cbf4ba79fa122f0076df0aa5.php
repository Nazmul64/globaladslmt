<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="d-flex justify-content-between mb-3">
        <h4>Ads List</h4>
        <a href="<?php echo e(route('ads.create')); ?>" class="btn btn-primary">Add New Ad</a>
    </div>
    <div class="card shadow">
        <div class="card-body">
            <?php if($ads->isEmpty()): ?>
                <p class="text-center">No ads found.</p>
            <?php else: ?>
            <table class="table table-bordered table-striped text-center">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Code</th>
                        <th>Show MRCE Ads</th>
                        <th>Show Button Timer Ads</th>
                        <th>Show Banner Ads</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $ads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($index + 1); ?></td>
                        <td><?php echo e($ad->code); ?></td>
                        <td><?php echo e(ucfirst($ad->show_mrce_ads)); ?></td>
                        <td><?php echo e(ucfirst($ad->show_button_timer_ads)); ?></td>
                        <td><?php echo e(ucfirst($ad->show_banner_ads)); ?></td>
                        <td>
                            <a href="<?php echo e(route('ads.edit', $ad->id)); ?>" class="btn btn-sm btn-warning">Edit</a>
                            <form action="<?php echo e(route('ads.destroy', $ad->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Are you sure?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\globaladslmt\resources\views\admin\ads\index.blade.php ENDPATH**/ ?>