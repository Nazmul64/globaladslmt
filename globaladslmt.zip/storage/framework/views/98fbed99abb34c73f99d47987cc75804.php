<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h2>Add New Item</h2>

    <form action="<?php echo e(route('whychooseu.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label>Title</label>
            <input type="text" name="title" class="form-control" placeholder="Enter title">
        </div>

        <div class="mb-3">
            <label>Description</label>
            <textarea name="description" class="form-control" rows="4" placeholder="Enter description"></textarea>
        </div>

        <div class="mb-3">
            <label>Icon (Font Awesome class)</label>
            <input type="text" name="icon" class="form-control" placeholder="e.g. fab fa-facebook">
        </div>

        <button class="btn btn-success">Create</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\globaladslmt\resources\views\admin\whychooseus\create.blade.php ENDPATH**/ ?>