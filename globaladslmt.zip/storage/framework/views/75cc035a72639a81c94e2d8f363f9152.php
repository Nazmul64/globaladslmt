<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h4 class="mb-3 fw-bold">Buy/Sell Posts</h4>

    <a href="<?php echo e(route('agentbuysellpost.create')); ?>" class="btn btn-primary mb-3">
        <i class="bi bi-plus-circle"></i> Create New Post
    </a>
    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>ID</th>
                <th>Category</th>
                <th>Photo</th>
                <th>Trade Limit</th>
                <th>Available Balance</th>
                <th>Duration</th>
                <th>Payment Name</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($post->id); ?></td>
                <td><?php echo e($post->category?->category_name ?? 'N/A'); ?></td>
                <td>
                    <?php if($post->photo): ?>
                        <img src="<?php echo e(asset($post->photo)); ?>" width="60" class="rounded">
                    <?php endif; ?>
                </td>
                <td><?php echo e($post->trade_limit); ?> - <?php echo e($post->trade_limit_two); ?></td>
                <td><?php echo e($post->available_balance); ?></td>
                <td><?php echo e($post->duration); ?> min</td>
                <td><?php echo e($post->payment_name); ?></td>
                <td><?php echo e(ucfirst($post->status)); ?></td>
                <td class="d-flex gap-1">
                    <a href="<?php echo e(route('agentbuysellpost.edit', $post->id)); ?>" class="btn btn-sm btn-success">
                        <i class="bi bi-pencil-square"></i>
                    </a>
                    <form action="<?php echo e(route('agentbuysellpost.destroy', $post->id)); ?>" method="POST" onsubmit="return confirm('Are you sure?');">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-sm btn-danger"><i class="bi bi-trash"></i></button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="9" class="text-center">No posts found.</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('agent.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\globaladslmt\resources\views\agent\agentbuysellpost\index.blade.php ENDPATH**/ ?>