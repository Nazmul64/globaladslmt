<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h3>Edit Stepguide</h3>

    <form action="<?php echo e(route('stepguide.update', $edit->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="mb-3">
            <label for="title" class="form-label">Title</label>
            <input type="text" class="form-control" name="title" id="title" value="<?php echo e(old('title', $edit->title)); ?>" required>
        </div>
        <div class="mb-3">
            <label for="description" class="form-label">Description</label>
            <textarea class="form-control" name="description" id="description" required><?php echo e(old('description', $edit->description)); ?></textarea>
        </div>
        <div class="mb-3">
            <label for="icon" class="form-label">Icon (Font Awesome Class)</label>
            <input type="text" class="form-control" name="icon" id="icon" value="<?php echo e(old('icon', $edit->icon)); ?>">
            <small>Example: fa-solid fa-box</small>
        </div>
        <div class="mb-3">
            <label for="serial_number" class="form-label">Serial Number</label>
            <input type="number" class="form-control" name="serial_number" id="serial_number" value="<?php echo e(old('serial_number', $edit->serial_number)); ?>" required>
        </div>
        <button type="submit" class="btn btn-primary"><i class="fa-solid fa-save"></i> Update Stepguide</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\globaladslmt\resources\views\admin\stepguide\edit.blade.php ENDPATH**/ ?>