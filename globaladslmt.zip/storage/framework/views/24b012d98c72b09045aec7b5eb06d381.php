<?php $__env->startSection('content'); ?>
<div class="container-fluid my-5">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card border-0 shadow-lg p-4" style="width:372px; margin:auto;">
                <h5 class="text-center mb-3 fw-bold">KYC Verification</h5>

                <?php
                    $kyc = Auth::user()->agentkyc ?? null;
                ?>

                
                <?php if($kyc): ?>
                    <div class="mb-3 text-center">
                        <h6>Your KYC Status:</h6>
                        <?php if($kyc->status == 'pending'): ?>
                            <span class="badge bg-warning text-dark">Pending</span>
                        <?php elseif($kyc->status == 'approved'): ?>
                            <span class="badge bg-success">Verified</span>
                        <?php else: ?>
                            <span class="badge bg-danger">Rejected</span>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

                
                <?php if(!$kyc || $kyc->status == 'rejected'): ?>
                <form method="POST" action="<?php echo e(route('agent.key.submit')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    <!-- Document Type -->
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Document Type</label>
                        <select name="document_type" class="form-control" required>
                            <option value="">-- Select Document Type --</option>
                            <option value="passport">Passport</option>
                            <option value="nid">NID</option>
                            <option value="driving_license">Driving License</option>
                        </select>
                        <?php $__errorArgs = ['document_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Front Side Photo -->
                    <div class="text-center mb-3">
                        <label class="form-label fw-semibold">Front Side Photo</label>
                        <img src="<?php echo e(asset('uploads/avator.jpg')); ?>" id="firstPhotoPreview"
                             class="rounded-circle border border-3 border-primary"
                             style="width:6rem;height:6rem;object-fit:cover;" />
                        <input type="file" name="document_first_part_photo"
                               class="form-control mt-2"
                               accept="image/*"
                               onchange="previewImage(event, 'firstPhotoPreview')" required>
                        <?php $__errorArgs = ['document_first_part_photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Back Side Photo -->
                    <div class="text-center mb-3">
                        <label class="form-label fw-semibold">Back Side Photo</label>
                        <img src="<?php echo e(asset('uploads/avator.jpg')); ?>" id="secondPhotoPreview"
                             class="rounded-circle border border-3 border-primary"
                             style="width:6rem;height:6rem;object-fit:cover;" />
                        <input type="file" name="document_secound_part_photo"
                               class="form-control mt-2"
                               accept="image/*"
                               onchange="previewImage(event, 'secondPhotoPreview')" required>
                        <?php $__errorArgs = ['document_secound_part_photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <button type="submit" class="btn btn-primary w-100 py-2 fw-bold">Submit KYC</button>
                </form>
                <?php else: ?>
                    <div class="text-center mt-3">
                        <span class="text-muted">You cannot upload again until admin reviews your KYC.</span>
                    </div>
                <?php endif; ?>

            </div>
        </div>
    </div>
</div>

<script>
function previewImage(event, previewId) {
    const reader = new FileReader();
    reader.onload = function(){
        document.getElementById(previewId).src = reader.result;
    };
    reader.readAsDataURL(event.target.files[0]);
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\globaladslmt\resources\views\agent\agent_key\kyc.blade.php ENDPATH**/ ?>