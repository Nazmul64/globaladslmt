<?php $__env->startSection('content'); ?>
      <div class="support-container">
        <!-- Support Header -->
        <div class="support-header">
            <h1>Need Help?</h1>
            <p>We're here to assist you 24/7</p>
        </div>

        <!-- Contact Methods -->
        <div class="contact-methods">
             <?php $__currentLoopData = $supports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e($item->url_link ?? '#'); ?>" class="contact-card whatsapp" target="_blank">
                    <i class="<?php echo e($item->icon ?? ''); ?>"></i>
                    <div class="contact-label"><?php echo e($item->name ?? ''); ?></div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\globaladslmt\resources\views\frontend\frontendpages\support.blade.php ENDPATH**/ ?>