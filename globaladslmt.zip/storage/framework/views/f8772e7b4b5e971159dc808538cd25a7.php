

  <div class="navbar-header">
  <div class="row align-items-center justify-content-between">
    <div class="col-auto">
      <div class="d-flex flex-wrap align-items-center gap-4">
        <button type="button" class="sidebar-toggle">
          <iconify-icon icon="heroicons:bars-3-solid" class="icon text-2xl non-active"></iconify-icon>
          <iconify-icon icon="iconoir:arrow-right" class="icon text-2xl active"></iconify-icon>
        </button>
        <button type="button" class="sidebar-mobile-toggle">
          <iconify-icon icon="heroicons:bars-3-solid" class="icon"></iconify-icon>
        </button>
        <form class="navbar-search">
          <input type="text" name="search" placeholder="Search">
          <iconify-icon icon="ion:search-outline" class="icon"></iconify-icon>
        </form>
      </div>
    </div>
    <div class="col-auto">
      <div class="d-flex flex-wrap align-items-center gap-3">
        <button type="button" data-theme-toggle
          class="w-40-px h-40-px bg-neutral-200 rounded-circle d-flex justify-content-center align-items-center"></button>
        <div class="dropdown">
          <button class="d-flex justify-content-center align-items-center rounded-circle" type="button"
            data-bs-toggle="dropdown">
            <img src="<?php echo e(asset('admin')); ?>/assets/images/user.png" alt="image" class="w-40-px h-40-px object-fit-cover rounded-circle">
          </button>
          <div class="dropdown-menu to-top dropdown-menu-sm">
            <div
              class="py-12 px-16 radius-8 bg-primary-50 mb-16 d-flex align-items-center justify-content-between gap-2">
              <div>
                <h6 class="text-lg text-primary-light fw-semibold mb-2"><?php echo e(Auth::user()->name ?? ''); ?></h6>
                <span class="text-secondary-light fw-medium text-sm"><?php echo e(Auth::user()->email ?? ''); ?></span>
              </div>
              <button type="button" class="hover-text-danger">
                <iconify-icon icon="radix-icons:cross-1" class="icon text-xl"></iconify-icon>
              </button>
            </div>
            <ul class="to-top-list">
              <li>
                <a class="dropdown-item text-black px-0 py-8 hover-bg-transparent hover-text-primary d-flex align-items-center gap-3"
                  href="<?php echo e(route('agent.profile')); ?>">
                  <iconify-icon icon="solar:user-linear" class="icon text-xl"></iconify-icon> My Profile</a>
              </li>
              <li>
                <a class="dropdown-item text-black px-0 py-8 hover-bg-transparent hover-text-primary d-flex align-items-center gap-3"
                  href="<?php echo e(route('agent.password.change')); ?>">
                  <iconify-icon icon="tabler:message-check" class="icon text-xl"></iconify-icon>Passwrod Change</a>
              </li>
              <a class="dropdown-item text-black px-0 py-8 hover-bg-transparent hover-text-primary d-flex align-items-center gap-3"
                  href="<?php echo e(route('agent.key')); ?>">
                  <iconify-icon icon="tabler:message-check" class="icon text-xl"></iconify-icon>Kyc Submit</a>
              </li>
             <li>
                <a class="dropdown-item text-black px-0 py-8 hover-bg-transparent hover-text-danger d-flex align-items-center gap-3"
                href="<?php echo e(route('agent.logout')); ?>"
                onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                    <iconify-icon icon="lucide:power" class="icon text-xl"></iconify-icon> Log Out
                </a>

                <form id="logout-form" action="<?php echo e(route('agent.logout')); ?>" method="POST" class="d-none">
                    <?php echo csrf_field(); ?>
                </form>
            </li>

            </ul>
          </div>
        </div><!-- Profile dropdown end -->
      </div>
    </div>
  </div>
</div>
<?php /**PATH E:\globaladslmt\resources\views\agent\pages\header.blade.php ENDPATH**/ ?>