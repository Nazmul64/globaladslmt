<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agent Registration</title>

    <!-- Favicon -->
    <link rel="icon" type="image/png" href="<?php echo e(asset('admin/assets/images/favicon.png')); ?>" sizes="16x16">

    <!-- Bootstrap & Icons -->
    <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/lib/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">

    <!-- Toastr CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" />

    <!-- Custom CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/style.css')); ?>">

    <!-- jQuery & Toastr JS -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
</head>
<body>

<section class="auth bg-base d-flex flex-wrap">

    <!-- Left Image Section -->
    <div class="auth-left d-lg-block d-none">
        <div class="d-flex align-items-center flex-column h-100 justify-content-center">
            <img src="<?php echo e(asset('admin/assets/images/auth/auth-img.png')); ?>" alt="Agent Illustration">
        </div>
    </div>

    <!-- Registration Form Section -->
    <div class="auth-right py-5 px-4 d-flex flex-column justify-content-center">
        <div class="max-w-464-px mx-auto w-100">
            <div class="text-center mb-4">
                <h4 class="fw-bold mb-3">Agent Registration</h4>
                <p class="text-muted">Create your agent account to start working with us.</p>
            </div>

            <form id="agentRegisterForm" action="<?php echo e(route('agent.register.submit')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <!-- Name -->
                <div class="position-relative mb-3">
                    <span class="position-absolute top-50 translate-middle-y ms-3 text-secondary">
                        <i class="bi bi-person"></i>
                    </span>
                    <input type="text" name="name" class="form-control h-56-px bg-neutral-50 radius-12 ps-5" placeholder="Enter Your Name" value="<?php echo e(old('name')); ?>">
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger small"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Email -->
                <div class="position-relative mb-3">
                    <span class="position-absolute top-50 translate-middle-y ms-3 text-secondary">
                        <i class="bi bi-envelope"></i>
                    </span>
                    <input type="email" name="email" class="form-control h-56-px bg-neutral-50 radius-12 ps-5" placeholder="Enter Your Email" value="<?php echo e(old('email')); ?>">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger small"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Country -->
                <div class="position-relative mb-3">
                    <select name="country" class="form-select h-56-px bg-neutral-50 radius-12">
                        <option value="" selected>Select Your Country</option>
                        <?php
                            $countries = ['United States','Canada','United Kingdom','Australia','Germany','France','India','Japan','China','Bangladesh'];
                        ?>
                        <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($country); ?>" <?php echo e(old('country') == $country ? 'selected' : ''); ?>><?php echo e($country); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger small"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Password -->
                <div class="position-relative mb-3">
                    <span class="position-absolute top-50 translate-middle-y ms-3 text-secondary">
                        <i class="bi bi-lock"></i>
                    </span>
                    <input type="password" name="password" id="password" class="form-control h-56-px bg-neutral-50 radius-12 ps-5" placeholder="Password">
                    <span class="toggle-password position-absolute end-0 top-50 translate-middle-y me-3 text-secondary" data-target="#password">
                        <i class="bi bi-eye"></i>
                    </span>
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger small"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Confirm Password -->
                <div class="position-relative mb-3">
                    <span class="position-absolute top-50 translate-middle-y ms-3 text-secondary">
                        <i class="bi bi-lock"></i>
                    </span>
                    <input type="password" name="password_confirmation" id="confirm_password" class="form-control h-56-px bg-neutral-50 radius-12 ps-5" placeholder="Confirm Password">
                </div>

                <!-- Register Button -->
                <button type="submit" class="btn btn-primary w-100 radius-12 py-3 mt-3">
                    Register
                </button>

                <!-- Login Redirect -->
                <div class="text-center mt-3">
                    <p class="text-muted mb-0">
                        Already have an account?
                        <a href="<?php echo e(route('agent.login')); ?>" class="text-primary text-decoration-underline">Login</a>
                    </p>
                </div>
            </form>
        </div>
    </div>
</section>

<!-- Bootstrap JS -->
<script src="<?php echo e(asset('admin/assets/js/lib/bootstrap.bundle.min.js')); ?>"></script>

<!-- Password Show/Hide Script -->
<script>
    $(document).ready(function(){
        $('.toggle-password').on('click', function() {
            const input = $($(this).attr('data-target'));
            const icon = $(this).find('i');
            if (input.attr('type') === 'password') {
                input.attr('type', 'text');
                icon.removeClass('bi-eye').addClass('bi-eye-slash');
            } else {
                input.attr('type', 'password');
                icon.removeClass('bi-eye-slash').addClass('bi-eye');
            }
        });
    });
</script>

<!-- ✅ Toastr Alert and Redirect -->
<?php if(Session::has('success')): ?>
<script>
    $(document).ready(function(){
        toastr.options = {
            closeButton: true,
            progressBar: true,
            positionClass: "toast-top-right",
            timeOut: 3000
        };
        toastr.success("<?php echo e(Session::get('success')); ?>");
        setTimeout(function(){
            window.location.href = "<?php echo e(route('agent.login')); ?>";
        }, 2000);
    });
</script>
<?php endif; ?>

<?php if(Session::has('error')): ?>
<script>
    $(document).ready(function(){
        toastr.options = {
            closeButton: true,
            progressBar: true,
            positionClass: "toast-top-right",
            timeOut: 5000
        };
        toastr.error("<?php echo e(Session::get('error')); ?>");
    });
</script>
<?php endif; ?>

</body>
</html>
<?php /**PATH E:\globaladslmt\resources\views\agent\login\register.blade.php ENDPATH**/ ?>