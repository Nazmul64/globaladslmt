<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h3>Add Referral Commission Level</h3>

    <form action="<?php echo e(route('reffercommission.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label>Referral Level</label>
            <input type="text" name="reffer_level" class="form-control" value="<?php echo e(old('reffer_level')); ?>">
            <?php $__errorArgs = ['reffer_level'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="mb-3">
            <label>Commission (%)</label>
            <input type="number" name="commission_percentage" class="form-control" value="<?php echo e(old('commission_percentage')); ?>" step="0.01">
            <?php $__errorArgs = ['commission_percentage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <button type="submit" class="btn btn-primary">Add Level</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\globaladslmt\resources\views\admin\reffercommission\create.blade.php ENDPATH**/ ?>