<?php $__env->startSection('content'); ?>
   <div class="friendrequest-container">
        <div class="friendrequest-header">
            <h2>Friend Requests</h2>
            <a href="#" class="friendrequest-see-all">See all</a>
        </div>

        <div class="friendrequest-grid">
            <!-- Friend Card 1 -->
            <div class="friendrequest-card">
                <img src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&h=400&fit=crop" alt="Mostofa Akter Mim" class="friendrequest-image">
                <div class="friendrequest-info">
                    <div class="friendrequest-name">Mostofa Akter Mim</div>
                    <div class="friendrequest-mutual-friends"></div>
                    <div class="friendrequest-button-group">
                        <button class="friendrequest-btn friendrequest-btn-confirm">Confirm</button>
                        <button class="friendrequest-btn friendrequest-btn-delete">Delete</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\globaladslmt\resources\views\frontend\frontendpages\friend_request.blade.php ENDPATH**/ ?>