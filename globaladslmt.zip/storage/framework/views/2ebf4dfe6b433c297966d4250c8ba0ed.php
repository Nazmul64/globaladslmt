<?php $__env->startSection('content'); ?>

<main class="dashboard-main">
  <div class="dashboard-main-body">
    <div class="d-flex align-items-center justify-content-between mb-4">
      <h6 class="fw-semibold mb-0">Add Deposit Limit</h6>
      <a href="<?php echo e(route('depositelimit.index')); ?>" class="btn btn-sm btn-outline-primary">Back</a>
    </div>
    <div class="card p-3">
      <form action="<?php echo e(route('depositelimit.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
          <label for="min_deposit" class="form-label">Minimum Deposit</label>
          <input type="number" class="form-control" name="min_deposit" id="min_deposit" value="<?php echo e(old('min_deposit')); ?>" required>
        </div>

        <div class="mb-3">
          <label for="max_deposit" class="form-label">Maximum Deposit</label>
          <input type="number" class="form-control" name="max_deposit" id="max_deposit" value="<?php echo e(old('max_deposit')); ?>" required>
        </div>

        <button type="submit" class="btn btn-primary">Save</button>
      </form>
    </div>
  </div>
</main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\globaladslmt\resources\views\admin\depositelimit\create.blade.php ENDPATH**/ ?>