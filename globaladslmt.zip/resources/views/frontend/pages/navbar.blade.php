<div class="top-header">
    <div class="header-content">
        <i class="fas fa-bars menu-icon" onclick="toggleSidebar()"></i>
        <div class="app-title">Global Money Ltd</div>

        <!-- Search Bar -->
        <div class="search-bar">
            <form id="searchForm" action="{{route('frontend.request')}}" method="GET">
                <input type="text" class="search-input" id="searchInput" name="query" placeholder="" autocomplete="off">
                <a style="list-style:one;" href="{{route('frontend.request')}}" class="search-button" onclick="performSearch()">
                    <i class="fas fa-search"></i>
                </a>
            </form>
        </div>

        <i class="fas fa-bell notification-icon" onclick="showNotification()"></i>
    </div>
</div>

<!-- Search Results Container -->
<div id="searchResultsContainer" class="search-results-container">
    <div id="resultList"></div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    // Typing animation for placeholder
    const searchInput = document.getElementById('searchInput');
    const text = "Search your friend";
    let index = 0;
    let isDeleting = false;
    let typingTimeout;

    function typeWriter() {
        if (!isDeleting && index <= text.length) {
            searchInput.placeholder = text.substring(0, index);
            index++;
            typingTimeout = setTimeout(typeWriter, 150);
        } else if (isDeleting && index >= 0) {
            searchInput.placeholder = text.substring(0, index);
            index--;
            typingTimeout = setTimeout(typeWriter, 100);
        } else {
            if (!isDeleting) {
                typingTimeout = setTimeout(() => {
                    isDeleting = true;
                    typeWriter();
                }, 2000);
            } else {
                isDeleting = false;
                index = 0;
                typingTimeout = setTimeout(typeWriter, 500);
            }
        }
    }

    // Start typing animation when page loads
    window.addEventListener('load', () => {
        typeWriter();
    });

    // Stop animation when user focuses on input
    searchInput.addEventListener('focus', () => {
        clearTimeout(typingTimeout);
        searchInput.placeholder = "Search your friend";
    });



</script>
