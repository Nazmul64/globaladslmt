<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AdSetting extends Model
{
   protected $fillable =[
     'ad_duration',
   ];
}
