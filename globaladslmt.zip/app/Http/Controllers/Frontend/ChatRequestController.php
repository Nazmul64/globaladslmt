<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\ChatRequest;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ChatRequestController extends Controller
{

public function friend_request(Request $request)
{
    $query = $request->input('query');
    $users = collect();

    if ($query) {
        $users = \App\Models\User::where('name', 'like', "%{$query}%")
            ->orWhere('email', 'like', "%{$query}%")
            ->get();
    }

    return view('frontend.frontendpages.friend_request', compact('users', 'query'));
}








}
